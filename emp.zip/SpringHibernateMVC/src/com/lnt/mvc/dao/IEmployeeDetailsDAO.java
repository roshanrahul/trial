package com.lnt.mvc.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.EmployeeDetails;


@Repository
public interface IEmployeeDetailsDAO {
	
	public void createEmployeeDetails(EmployeeDetails EmployeeDetails);
	public void updateEmployeeDetails(EmployeeDetails EmployeeDetails);
	public void deleteEmployeeDetails(int id);
	
	public EmployeeDetails getEmployeeDetails(int id);
	public List<EmployeeDetails> getByName(String name);
}
