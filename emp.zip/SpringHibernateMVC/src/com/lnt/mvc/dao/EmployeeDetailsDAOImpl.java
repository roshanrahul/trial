package com.lnt.mvc.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.EmployeeDetails;
import com.lnt.mvc.model.Person;

@Repository
public class EmployeeDetailsDAOImpl implements IEmployeeDetailsDAO{

	
	private static final Logger logger = 			
			LoggerFactory.getLogger(PersonDaoImpl.class);

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	
	@Override
	public void createEmployeeDetails(EmployeeDetails EmployeeDetails) {
	 
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(EmployeeDetails);
		logger.info("Employee"
				+ " saved successfully, Person Details="
		+EmployeeDetails  );
	}

	@Override
	public void updateEmployeeDetails(EmployeeDetails EmployeeDetails) {
		Session session = 
				this.sessionFactory
				.getCurrentSession();
		session.update(EmployeeDetails);
		logger.info("Employee updated successfully, "
				+ "Employee Details=" + EmployeeDetails);
		
	}

	@Override
	public void deleteEmployeeDetails(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		EmployeeDetails e = 
		( EmployeeDetails) session.load(Person.class, new Integer(id));
		if (null != e) {
			session.delete(e);
		}else {
			logger.error
			("Person NOT deleted, with person Id=" +id);
		}
		logger.info("Person deleted successfully, person details=" +e);
		
	}

	@Override
	public EmployeeDetails getEmployeeDetails(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		EmployeeDetails p = ( EmployeeDetails) session.load( EmployeeDetails.class, new Integer(id));
		logger.info("Employee loaded successfully, Person details=" + p);
		return p;
		 
	}

	@Override
	public List<EmployeeDetails> getByName(String name) {
		Session session = this.sessionFactory.getCurrentSession();
//		List<EmployeeDetails> personsList = session.createQuery("from EmployeeDetails").list();
		List<EmployeeDetails> personsList = ( List<EmployeeDetails>) session.load( EmployeeDetails.class, new String(name));
		logger.info("Person loaded successfully, Person details=" + personsList);
		
		for (EmployeeDetails p : personsList) {
			logger.info("Person List::" + p);
		}
		return personsList;
		 
	}

}
