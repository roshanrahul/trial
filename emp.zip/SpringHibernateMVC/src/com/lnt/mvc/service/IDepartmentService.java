package com.lnt.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lnt.mvc.model.Department;
@Service
public interface IDepartmentService {

	public void createDepartment(Department dept);
	
	public void updateDepartment(Department dept);
	
	public void deleteDepartment(int deptidt);
	
	
	public Department getDepartment(int id);
	public List<Department> getByName(String name);
	
}
