package com.lnt.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.mvc.dao.IDepartmentDAO;
import com.lnt.mvc.model.Department;

@Service
public class DepartmentService implements IDepartmentService {

	private IDepartmentDAO iDepartmentDAO ;
	
	
	
	
	@Autowired
	 public void setiDepartmentDAO(IDepartmentDAO iDepartmentDAO) {
		this.iDepartmentDAO = iDepartmentDAO;
	}


 

	
	@Override
	@Transactional
	public void createDepartment(Department dept) {
		 
		this. iDepartmentDAO.createDepartment(dept);
	}

	@Override
	@Transactional
	public void updateDepartment(Department dept) {
		this. iDepartmentDAO.updateDepartment(dept);
		
	}

	@Override
	@Transactional
	public void deleteDepartment(int deptidt) {
		this. iDepartmentDAO.deleteDepartment(deptidt);
		
	}

	@Override
	@Transactional
	public Department getDepartment(int id) {
		return this. iDepartmentDAO.getDepartment(id);
		
	}

	@Override
	@Transactional
	public List<Department> getByName(String name) {
		 
		return this. iDepartmentDAO.getByName(name);
	}

}
