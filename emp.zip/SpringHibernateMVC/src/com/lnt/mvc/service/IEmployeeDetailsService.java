package com.lnt.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lnt.mvc.model.EmployeeDetails;
@Service
public interface IEmployeeDetailsService {
	public void createEmployeeDetails(EmployeeDetails EmployeeDetails);
	public void updateEmployeeDetails(EmployeeDetails EmployeeDetails);
	public void deleteEmployeeDetails(int id);
	
	public EmployeeDetails getEmployeeDetails(int id);
	public List<EmployeeDetails> getByName(String name);
}
