package com.lnt.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.mvc.dao.IEmployeeDetailsDAO;
import com.lnt.mvc.model.EmployeeDetails;


@Service
public class EmployeeDetailsService implements IEmployeeDetailsService {
	
	
private IEmployeeDetailsDAO  iEmployeeDetailsDAO ;



@Autowired
public void setiEmployeeDetailsDAO(IEmployeeDetailsDAO iEmployeeDetailsDAO) {
	this.iEmployeeDetailsDAO = iEmployeeDetailsDAO;
}

 



@Override
@Transactional
public void createEmployeeDetails(EmployeeDetails EmployeeDetails) {
 this. iEmployeeDetailsDAO.createEmployeeDetails(EmployeeDetails);
	
}

@Override
@Transactional
public void updateEmployeeDetails(EmployeeDetails EmployeeDetails) {
 
	this. iEmployeeDetailsDAO.updateEmployeeDetails(EmployeeDetails);
}

@Override
@Transactional
public void deleteEmployeeDetails(int id) {
	 this.iEmployeeDetailsDAO.deleteEmployeeDetails(id);
}

@Override
@Transactional
public EmployeeDetails getEmployeeDetails(int id) {
	
	return this. iEmployeeDetailsDAO.getEmployeeDetails(id);
}

@Override
@Transactional
public List<EmployeeDetails> getByName(String name) {
	 
	return this. iEmployeeDetailsDAO.getByName(name);
}

}
