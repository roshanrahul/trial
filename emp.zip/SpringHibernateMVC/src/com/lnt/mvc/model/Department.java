package com.lnt.mvc.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
public class Department {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int department_id;
	
	@Column
	private String departmentName;
	
	
	private List<EmployeeDetails>employee;


	public int getDepartment_id() {
		return department_id;
	}


	public void setDepartment_id(int department_id) {
		this.department_id = department_id;
	}


	public String getDepartmentName() {
		return departmentName;
	}


	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}


	public List<EmployeeDetails> getEmployee() {
		return employee;
	}


	public void setEmployee(List<EmployeeDetails> employee) {
		this.employee = employee;
	}


	public Department(int department_id, String departmentName, List<EmployeeDetails> employee) {
		super();
		this.department_id = department_id;
		this.departmentName = departmentName;
		this.employee = employee;
	}


	public Department() {
		super();
	}


	@Override
	public String toString() {
		return "Department [department_id=" + department_id + ", departmentName=" + departmentName + ", employee="
				+ employee + "]";
	}
	
	
}
