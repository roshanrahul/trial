package com.lnt.mvc.model;

import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;


@Component
public class EmployeeDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int employee_id;
	private String firstName;
	private String lastname;
	private String EmailAddress;
	private double salary;
	private int phoneNumber;
	private String password;
	private int jobId;
	
	private int department_id;
	private Date hireDate;
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmailAddress() {
		return EmailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		EmailAddress = emailAddress;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public int getDepartment_id() {
		return department_id;
	}
	public void setDepartment_id(int department_id) {
		this.department_id = department_id;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	public EmployeeDetails(int employee_id, String firstName, String lastname, String emailAddress, double salary,
			int phoneNumber, String password, int jobId, int department_id, Date hireDate) {
		super();
		this.employee_id = employee_id;
		this.firstName = firstName;
		this.lastname = lastname;
		EmailAddress = emailAddress;
		this.salary = salary;
		this.phoneNumber = phoneNumber;
		this.password = password;
		this.jobId = jobId;
		this.department_id = department_id;
		this.hireDate = hireDate;
	}
	public EmployeeDetails() {
		super();
	}
	@Override
	public String toString() {
		return "EmployeeDetails [employee_id=" + employee_id + ", firstName=" + firstName + ", lastname=" + lastname
				+ ", EmailAddress=" + EmailAddress + ", salary=" + salary + ", phoneNumber=" + phoneNumber
				+ ", password=" + password + ", jobId=" + jobId + ", department_id=" + department_id + ", hireDate="
				+ hireDate + "]";
	}
	
 
	 
	 
	
}
