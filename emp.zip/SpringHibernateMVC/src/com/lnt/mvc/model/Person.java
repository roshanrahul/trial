package com.lnt.mvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.NotEmpty;
import org.hibernate.validator.Size;

@Entity
@Table(name="MYPERSON")
public class Person {
@Id
@Column(name="id")
@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;

@Size(max=20,min=3,message="Name Entered is invalid.It must be between 3 and 20")
	private String  name;

@NotEmpty(message="Country name cannot be empty!")
	private String country;
 
	public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Person(Integer id, String name, String country) {
		super();
		this.id = id;
		this.name = name;
		this.country = country;
	}
	public Person() {
		super();
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", country=" + country + "]";
	}

	
	
}
