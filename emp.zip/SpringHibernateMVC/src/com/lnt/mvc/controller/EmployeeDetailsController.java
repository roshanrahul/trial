package com.lnt.mvc.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.mvc.exception.CustomException;
import com.lnt.mvc.model.EmployeeDetails;
import com.lnt.mvc.model.Person;
import com.lnt.mvc.service.IEmployeeDetailsService;


@Controller
public class EmployeeDetailsController {
@Autowired
private IEmployeeDetailsService  iEmployeeDetailsService;

 


//@Qualifier(value = " iEmployeeDetailsService")
public void setiEmployeeDetailsService(IEmployeeDetailsService iEmployeeDetailsService) {
	this.iEmployeeDetailsService = iEmployeeDetailsService;
}

 
@RequestMapping(value = "/employee", method = RequestMethod.GET)
public String listPersons(Model model) {
	model.addAttribute("employeeDetails", new EmployeeDetails());// model
//	model.addAttribute("listPersons", 
//			this.empService.listPersons());
	return "employees";// view name
}








//@RequestMapping(value = "/person/add", 
//method = RequestMethod.POST)
//@ExceptionHandler({ CustomException.class })
//public String addPerson(
//@ModelAttribute("person") 
//@Valid Person p, 
//BindingResult result, 
//Model model) {
//if (!result.hasErrors()) {
//if (p.getId() == null) {
//	// new person, add it
//	this.empService.addPerson(p);
//} else {
//	// existing person, call update
//	this.empService.updatePerson(p);
//}
//return "redirect:/persons";
//}


}
